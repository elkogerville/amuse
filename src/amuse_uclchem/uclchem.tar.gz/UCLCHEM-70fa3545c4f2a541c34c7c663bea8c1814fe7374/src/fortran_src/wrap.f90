!The interface between main fortran code and python.
!wrap.f90 subroutines are all accessible through the python wrap.
! Core algorithm is found in solveAbundances subroutine below, all others call it
MODULE uclchemwrap
    USE constants
    USE DEFAULTPARAMETERS
    !f2py INTEGER, parameter :: dp
    USE physicscore
    USE chemistry
    USE io
    USE heating
    USE COOLANT_MODULE
    USE F2PY_CONSTANTS
    USE postprocess_mod, ONLY: postprocess_error
    IMPLICIT NONE
CONTAINS
    SUBROUTINE cloud(dictionary, outSpeciesIn,returnArray,returnRateConstants,&
            &givestartabund,timePoints,gridPoints,physicsarray,chemicalabunarray,&
            &rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart ,abundance_out,specname_out,successFlag)
        !f2py threadsafe
        !Subroutine to call a cloud model, used to interface with python
        ! Loads cloud specific subroutines and send to solveAbundances
        !
        !Args:
        ! dictionary - python parameter dictionary
        ! outSpeciesIn - list of species to output as a space separated string
        ! returnArray - boolean on whether arrays will be returned
        ! returnRateConstants - boolean on whether to write rates to file, or return to memory (if returnArray is True)
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep
        ! abundanceStart - array containing starting chemical conditions
        !Returns:
        ! abundance_out - list of abundances of species in outSpeciesIn
        ! specname_out - array of species that are in the chemicalabunarray
        ! successFlag - integer flag indicating success or fail
        
        USE cloud_mod
        USE DEFAULTPARAMETERS

        !f2py integer, intent(aux) :: nspec, n_physics_params, nHeatingTerms, N_DVODE_STATS, N_TOTAL_LEVELS, N_SE_STATS_PER_COOLANT
        !f2py intent(out) abundance_out, specname_out
        CHARACTER(LEN=*), INTENT(IN) :: dictionary, outSpeciesIn
        DOUBLE PRECISION, INTENT(OUT) :: abundance_out(nspec)
        CHARACTER(LEN=32), INTENT(OUT) :: specname_out(nspec)
        INTEGER :: successFlag
        !f2py intent(in) dictionary,outSpeciesIn
        !f2py intent(out) successFlag
        LOGICAL, INTENT(IN) :: returnArray
        !f2py intent(in) returnArray
        LOGICAL, INTENT(IN) :: returnRateConstants
        !f2py intent(in) returnRateConstants
        LOGICAL, INTENT(IN) :: givestartabund
        !f2py intent(in) givestartabund
        INTEGER, INTENT(IN) :: gridPoints
        !f2py intent(in) gridPoints
        INTEGER, INTENT(IN) :: timePoints
        !f2py intent(in) timePoints

        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, n_physics_params) :: physicsarray
        !f2py intent(in,out) physicsarray
        !f2py depend(timePoints,gridPoints, n_physics_params) physicsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nspec) :: chemicalabunarray
        !f2py intent(in,out) chemicalabunarray
        !f2py depend(timePoints,gridPoints,nspec) chemicalabunarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nReac) :: rateConstantsArray
        !f2py intent(in,out) rateConstantsArray
        !f2py depend(timePoints,gridPoints,nReac) rateConstantsArray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nHeatingTerms) :: heatarray
        !f2py intent(in,out) heatarray
        !f2py depend(timePoints,gridPoints,nHeatingTerms) heatarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_DVODE_STATS) :: statsarray
        !f2py intent(in,out) statsarray
        !f2py depend(timePoints,gridPoints,N_DVODE_STATS) statsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_TOTAL_LEVELS) :: levelpopulationsarray
        !f2py intent(in,out) levelpopulationsarray
        !f2py depend(timePoints,gridPoints,N_TOTAL_LEVELS) levelpopulationsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, NCOOLANTS*N_SE_STATS_PER_COOLANT) :: sestatsarray
        !f2py intent(in,out) sestatsarray
        !f2py depend(timePoints,gridPoints,NCOOLANTS,N_SE_STATS_PER_COOLANT) sestatsarray
        DOUBLE PRECISION, OPTIONAL, DIMENSION(gridPoints, nspec) :: abundanceStart
        !f2py intent(in) abundanceStart
        !f2py depend(gridPoints, nspec) abundanceStart


        successFlag=0
        specname_out = specName
        CALL solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
                &updatePhysics,updateTargetTime,sublimation,returnArray,returnRateConstants,givestartabund,&
                &timePoints,physicsarray,chemicalabunarray,rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart)
        IF ((ALLOCATED(outIndx)) .and. (successFlag .eq. 0)) THEN
            abundance_out(1:SIZE(outIndx))=abund(outIndx,1)
        END IF

    END SUBROUTINE cloud

    SUBROUTINE collapse(collapseIn,dictionary,outSpeciesIn,&
            &returnArray,returnRateConstants,givestartabund,timePoints,gridPoints,physicsarray,chemicalabunarray,&
            &rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart, abundance_out,specname_out,successFlag)
        !f2py threadsafe
        !Subroutine to call a collapse model, used to interface with python
        ! Loads model specific subroutines and send to solveAbundances
        !
        !Args:
        ! collapseIn - integer indicating which collapse mode to run
        ! dictionary - python parameter dictionary
        ! outSpeciesIn - list of species to output as a space separated string
        ! returnArray - boolean on whether arrays will be returned
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep
        ! abundanceStart - array containing starting chemical conditions
        !Returns:
        ! abundance_out - list of abundances of species in outSpeciesIn
        ! specname_out - array of species that are in the chemicalabunarray
        ! successFlag - integer flag indicating success or fail

        USE collapse_mod
        USE DEFAULTPARAMETERS

        !f2py integer,parameter intent(aux) nspec, n_physics_params, nHeatingTerms, N_DVODE_STATS, N_TOTAL_LEVELS, N_SE_STATS_PER_COOLANT
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        DOUBLE PRECISION :: abundance_out(nspec)
        CHARACTER(LEN=32) :: specname_out(nspec)
        INTEGER :: successFlag,collapseIn
        !f2py intent(in) collapseIn,dictionary,outSpeciesIn
        !f2py intent(out) abundance_out,specname_out,successFlag
        LOGICAL, INTENT(IN) :: returnArray
        !f2py intent(in) returnArray
        LOGICAL, INTENT(IN) :: returnRateConstants
        !f2py intent(in) returnRateConstants
        LOGICAL, INTENT(IN) :: givestartabund
        !f2py intent(in) givestartabund
        INTEGER, INTENT(IN) :: gridPoints
        !f2py intent(in) gridPoints
        INTEGER, INTENT(IN) :: timePoints
        !f2py intent(in) timePoints
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, n_physics_params) :: physicsarray
        !f2py intent(in,out) physicsarray
        !f2py depend(gridPoints) physicsarray
        DOUBLE PRECISION, INTENT(INOUT), DIMENSION(timePoints+1, gridPoints, nspec), OPTIONAL :: chemicalabunarray
        !f2py intent(in,out) chemicalabunarray
        !f2py depend(gridPoints) chemicalabunarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nReac) :: rateConstantsArray
        !f2py intent(in,out) rateConstantsArray
        !f2py depend(timePoints,gridPoints,nReac) rateConstantsArray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nHeatingTerms) :: heatarray
        !f2py intent(in,out) heatarray
        !f2py depend(timePoints,gridPoints,nHeatingTerms) heatarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_DVODE_STATS) :: statsarray
        !f2py intent(in,out) statsarray
        !f2py depend(timePoints,gridPoints,N_DVODE_STATS) statsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_TOTAL_LEVELS) :: levelpopulationsarray
        !f2py intent(in,out) levelpopulationsarray
        !f2py depend(timePoints,gridPoints,N_TOTAL_LEVELS) levelpopulationsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, NCOOLANTS*N_SE_STATS_PER_COOLANT) :: sestatsarray
        !f2py intent(in,out) sestatsarray
        !f2py depend(timePoints,gridPoints,NCOOLANTS,N_SE_STATS_PER_COOLANT) sestatsarray
        DOUBLE PRECISION, OPTIONAL, DIMENSION(gridPoints, nspec) :: abundanceStart
        !f2py intent(in) abundanceStart
        !f2py depend(gridPoints, nspec) abundanceStart
        successFlag=0
        specname_out(:nspec) = specName
        collapse_mode=collapseIn

        CALL solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
                &updatePhysics,updateTargetTime,sublimation,returnArray, returnRateConstants,givestartabund,&
                &timepoints,physicsarray,chemicalabunarray,rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart)

        IF ((ALLOCATED(outIndx)) .and. (successFlag .eq. 0)) THEN
            abundance_out(1:SIZE(outIndx))=abund(outIndx,1)
        END IF
    END SUBROUTINE collapse

    SUBROUTINE hot_core(temp_index,max_temp,dictionary,outSpeciesIn,returnArray,&
            &returnRateConstants,givestartabund,timePoints,gridPoints,physicsarray,chemicalabunarray,&
            &rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart, abundance_out,specname_out,successFlag)
        !f2py threadsafe
        !Subroutine to call a hot core model, used to interface with python
        ! Loads model specific subroutines and send to solveAbundances
        !
        !Args:
        ! temp_index - integer indicating which mass hot core to run - see hotcore.90
        ! max_temp - maximum temperature before we stop increasing.
        ! dictionary - python parameter dictionary
        ! outSpeciesIn - list of species to output as a space separated string
        ! returnArray - boolean on whether arrays will be returned
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep
        ! abundanceStart - array containing starting chemical conditions
        !Returns:
        ! abundance_out - list of abundances of species in outSpeciesIn
        ! successFlag - integer flag indicating success or fail
        USE hotcore
        USE DEFAULTPARAMETERS

        !f2py integer, parameter intent(aux) nspec, n_physics_params, nHeatingTerms, N_DVODE_STATS
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        DOUBLE PRECISION :: abundance_out(nspec),max_temp
        INTEGER :: temp_index,successFlag
        CHARACTER(LEN=32) :: specname_out(nspec)
        !f2py intent(in) temp_index,max_temp,dictionary,outSpeciesIn
        !f2py intent(out) abundance_out,specname_out,successFlag
        LOGICAL, INTENT(IN) :: returnArray
        !f2py intent(in) returnArray
        LOGICAL, INTENT(IN) :: returnRateConstants
        !f2py intent(in) returnRateConstants
        LOGICAL, INTENT(IN) :: givestartabund
        !f2py intent(in) givestartabund
        INTEGER, INTENT(IN) :: gridPoints
        !f2py intent(in) gridPoints
        INTEGER, INTENT(IN) :: timePoints
        !f2py intent(in) timePoints
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, n_physics_params) :: physicsarray
        !f2py intent(in, out) physicsarray
        !f2py depend(gridPoints) physicsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nspec) :: chemicalabunarray
        !f2py intent(in, out) chemicalabunarray
        !f2py depend(gridPoints) chemicalabunarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nReac) :: rateConstantsArray
        !f2py intent(in,out) rateConstantsArray
        !f2py depend(timePoints,gridPoints,nReac) rateConstantsArray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nHeatingTerms) :: heatarray
        !f2py intent(in,out) heatarray
        !f2py depend(timePoints,gridPoints,nHeatingTerms) heatarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_DVODE_STATS) :: statsarray
        !f2py intent(in,out) statsarray
        !f2py depend(timePoints,gridPoints,N_DVODE_STATS) statsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_TOTAL_LEVELS) :: levelpopulationsarray
        !f2py intent(in,out) levelpopulationsarray
        !f2py depend(timePoints,gridPoints,N_TOTAL_LEVELS) levelpopulationsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, NCOOLANTS*N_SE_STATS_PER_COOLANT) :: sestatsarray
        !f2py intent(in,out) sestatsarray
        !f2py depend(timePoints,gridPoints,NCOOLANTS,N_SE_STATS_PER_COOLANT) sestatsarray
        DOUBLE PRECISION, OPTIONAL, DIMENSION(gridPoints, nspec) :: abundanceStart
        !f2py intent(in) abundanceStart
        !f2py depend(gridPoints, nspec) abundanceStart
        specname_out(:nspec) = specName
        maxTemp=max_temp
        tempIndx=temp_index

        CALL solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
        &updatePhysics,updateTargetTime,sublimation,returnArray, returnRateConstants,givestartabund,&
        &timepoints,physicsarray,chemicalabunarray,rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart)

        IF ((ALLOCATED(outIndx)) .and. (successFlag .eq. 0)) THEN
            abundance_out(1:SIZE(outIndx))=abund(outIndx,1)
        END IF
    END SUBROUTINE hot_core

    SUBROUTINE cshock(shock_vel,timestep_factor,minimum_temperature,dictionary, outSpeciesIn,&
            &returnArray,returnRateConstants,givestartabund,timePoints,gridPoints,physicsarray,chemicalabunarray,&
            &rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart, abundance_out,dissipation_time,specname_out,successFlag)
        !f2py threadsafe
        !Subroutine to call a C-shock model, used to interface with python
        ! Loads model specific subroutines and send to solveAbundances
        !
        !Args:
        ! shock_vel - double precision shock velocity in km/s
        ! timestep_factor - Multiply dissipation time of the shock by this double precision factor to
        !                  get the timestep for the simulation up until dissipation time is reached
        ! minimum_temperature - float indicating minimum temperature before we stop post shock cooling.
        !                        set to zero to disable.
        ! dictionary - python parameter dictionary
        ! outSpeciesIn - list of species to output as a space separated string
        ! returnArray - boolean on whether arrays will be returned
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep
        ! abundanceStart - array containing starting chemical conditions
        !Returns:
        ! abundance_out - list of abundances of species in outSpeciesIn
        ! dissipation_time - float, dissipation time in years
        ! successFlag - integer flag indicating success or fail
        USE cshock_mod
        USE DEFAULTPARAMETERS

        !f2py integer, parameter intent(aux) nspec, n_physics_params, nHeatingTerms, N_DVODE_STATS
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        DOUBLE PRECISION :: abundance_out(nspec),shock_vel,timestep_factor
        DOUBLE PRECISION :: minimum_temperature,dissipation_time
        INTEGER :: successFlag
        CHARACTER(LEN=32) :: specname_out(nspec)
        !f2py intent(in) shock_vel,timestep_factor,minimum_temperature,dictionary,outSpeciesIn
        !f2py intent(out) abundance_out,dissipation_time,specname_out,successFlag
        LOGICAL, INTENT(IN) :: returnArray
        !f2py intent(in) returnArray
        LOGICAL, INTENT(IN) :: returnRateConstants
        !f2py intent(in) returnRateConstants
        LOGICAL, INTENT(IN) :: givestartabund
        !f2py intent(in) givestartabund
        INTEGER, INTENT(IN) :: gridPoints
        !f2py intent(in) gridPoints
        INTEGER, INTENT(IN) :: timePoints
        !f2py intent(in) timePoints
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, n_physics_params) :: physicsarray
        !f2py intent(in, out) physicsarray
        !f2py depend(gridPoints) physicsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nspec) :: chemicalabunarray
        !f2py intent(in, out) chemicalabunarray
        !f2py depend(gridPoints) chemicalabunarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nReac) :: rateConstantsArray
        !f2py intent(in,out) rateConstantsArray
        !f2py depend(timePoints,gridPoints,nReac) rateConstantsArray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nHeatingTerms) :: heatarray
        !f2py intent(in,out) heatarray
        !f2py depend(timePoints,gridPoints,nHeatingTerms) heatarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_DVODE_STATS) :: statsarray
        !f2py intent(in,out) statsarray
        !f2py depend(timePoints,gridPoints,N_DVODE_STATS) statsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_TOTAL_LEVELS) :: levelpopulationsarray
        !f2py intent(in,out) levelpopulationsarray
        !f2py depend(timePoints,gridPoints,N_TOTAL_LEVELS) levelpopulationsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, NCOOLANTS*N_SE_STATS_PER_COOLANT) :: sestatsarray
        !f2py intent(in,out) sestatsarray
        !f2py depend(timePoints,gridPoints,NCOOLANTS,N_SE_STATS_PER_COOLANT) sestatsarray
        DOUBLE PRECISION, OPTIONAL, DIMENSION(gridPoints, nspec) :: abundanceStart
        !f2py intent(in) abundanceStart
        !f2py depend(gridPoints, nspec) abundanceStart

        vs=shock_vel
        timestepFactor=timestep_factor
        minimumPostshockTemp=minimum_temperature

        specname_out = specName
        successFlag=0
        CALL solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
                &updatePhysics,updateTargetTime,sublimation,returnArray, returnRateConstants,givestartabund,&
                &timepoints,physicsarray,chemicalabunarray,rateConstantsArray,heatarray,statsarray,levelpopulationsarray, sestatsarray,abundanceStart)

        IF (successFlag .eq. 0) THEN
            IF (ALLOCATED(outIndx)) abundance_out(1:SIZE(outIndx))=abund(outIndx,1)
            dissipation_time=dissipationTime
        END IF
    END SUBROUTINE cshock

    SUBROUTINE jshock(shock_vel,dictionary,outSpeciesIn,returnArray,returnRateConstants,givestartabund,&
            &timePoints,gridPoints,physicsarray,chemicalabunarray,&
            &rateConstantsArray, heatarray, statsarray, levelpopulationsarray, sestatsarray, abundanceStart,abundance_out,specname_out,successFlag)
        !f2py threadsafe
        !Subroutine to call a J-shock model, used to interface with python
        ! Loads model specific subroutines and send to solveAbundances
        !
        !Args:
        ! shock_vel - double precision shock velocity in km/s
        ! dictionary - python parameter dictionary
        ! outSpeciesIn - list of species to output as a space separated string
        ! returnArray - boolean on whether arrays will be returned
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep
        ! abundanceStart - array containing starting chemical conditions
        !Returns:
        ! abundance_out - list of abundances of species in outSpeciesIn
        ! successFlag - integer flag indicating success or fail
        USE jshock_mod
        USE DEFAULTPARAMETERS

        !f2py integer, parameter intent(aux) nspec, n_physics_params, nHeatingTerms, N_DVODE_STATS
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        DOUBLE PRECISION :: abundance_out(nspec),shock_vel
        INTEGER :: successFlag
        CHARACTER(LEN=32) :: specname_out(nspec)
        !f2py intent(in) shock_vel,dictionary,outSpeciesIn
        !f2py intent(out) abundance_out, specname_out, successFlag
        LOGICAL, INTENT(IN) :: returnArray
        !f2py intent(in) returnArray
        LOGICAL, INTENT(IN) :: returnRateConstants
        !f2py intent(in) returnRateConstants
        LOGICAL, INTENT(IN) :: givestartabund
        !f2py intent(in) givestartabund
        INTEGER, INTENT(IN) :: gridPoints
        !f2py intent(in) gridPoints
        INTEGER, INTENT(IN) :: timePoints
        !f2py intent(in) timePoints
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints + 1, gridPoints, n_physics_params) :: physicsarray
        !f2py intent(in, out) physicsarray
        !f2py depend(gridPoints) physicsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints + 1, gridPoints, nspec) :: chemicalabunarray
        !f2py intent(in, out) chemicalabunarray
        !f2py depend(gridPoints) chemicalabunarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nReac) :: rateConstantsArray
        !f2py intent(in,out) rateConstantsArray
        !f2py depend(timePoints,gridPoints,nReac) rateConstantsArray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nHeatingTerms) :: heatarray
        !f2py intent(in,out) heatarray
        !f2py depend(timePoints,gridPoints,nHeatingTerms) heatarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_DVODE_STATS) :: statsarray
        !f2py intent(in,out) statsarray
        !f2py depend(timePoints,gridPoints,N_DVODE_STATS) statsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_TOTAL_LEVELS) :: levelpopulationsarray
        !f2py intent(in,out) levelpopulationsarray
        !f2py depend(timePoints,gridPoints,N_TOTAL_LEVELS) levelpopulationsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, NCOOLANTS*N_SE_STATS_PER_COOLANT) :: sestatsarray
        !f2py intent(in,out) sestatsarray
        !f2py depend(timePoints,gridPoints,NCOOLANTS,N_SE_STATS_PER_COOLANT) sestatsarray
        DOUBLE PRECISION, OPTIONAL, DIMENSION(gridPoints, nspec) :: abundanceStart
        !f2py intent(in) abundanceStart
        !f2py depend(gridPoints, nspec) abundanceStart
        vs=shock_vel
        CALL solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
        &updatePhysics,updateTargetTime,sublimation,returnArray, returnRateConstants,givestartabund,&
        &timepoints,physicsarray,chemicalabunarray,rateConstantsArray,heatarray,statsarray,levelpopulationsarray, sestatsarray,abundanceStart)

        specname_out(:nspec) = specName
        IF ((ALLOCATED(outIndx)) .and. (successFlag .eq. 0)) THEN
            abundance_out(1:SIZE(outIndx))=abund(outIndx,1)
        END IF
    END SUBROUTINE jshock

    SUBROUTINE postprocess(dictionary,outSpeciesIn,returnArray,returnRateConstants,givestartabund,&
        &timePoints,gridPoints,physicsarray,chemicalabunarray,rateConstantsArray,heatarray,statsarray,&
        &levelpopulationsarray, sestatsarray, abundanceStart,timegrid,densgrid,gastempgrid,dusttempgrid,radfieldgrid,zetagrid,useav,avgrid,&
        &usecoldens,nhgrid,nh2grid,ncogrid,ncgrid,abundance_out,specname_out,successFlag)
        !f2py threadsafe
        !Subroutine to call a J-shock model, used to interface with python
        ! Loads model specific subroutines and send to solveAbundances
        !
        !Args:
        ! shock_vel - double precision shock velocity in km/s
        ! dictionary - python parameter dictionary
        ! outSpeciesIn - list of species to output as a space separated string
        ! returnArray - boolean on whether arrays will be returned
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep
        ! abundanceStart - array containing starting chemical conditions
        !Returns:
        ! abundance_out - list of abundances of species in outSpeciesIn
        ! successFlag - integer flag indicating success or fail
        USE postprocess_mod  
        USE DEFAULTPARAMETERS

        !f2py integer, parameter intent(aux) nspec, n_physics_params, nHeatingTerms, N_DVODE_STATS
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        DOUBLE PRECISION :: abundance_out(nspec)
        INTEGER :: successFlag
        CHARACTER(LEN=32) :: specname_out(nspec)
        !f2py intent(in) shock_vel,dictionary,outSpeciesIn
        !f2py intent(out) abundance_out, specname_out, successFlag
        LOGICAL, INTENT(IN) :: returnArray
        !f2py intent(in) returnArray
        LOGICAL, INTENT(IN) :: returnRateConstants
        !f2py intent(in) returnRateConstants
        LOGICAL, INTENT(IN) :: givestartabund
        !f2py intent(in) givestartabund
        INTEGER, INTENT(IN) :: gridPoints
        !f2py intent(in) gridPoints
        INTEGER, INTENT(IN) :: timePoints
        !f2py intent(in) timePoints
        LOGICAL, INTENT(IN) :: useav
        !f2py intent(in) useav
        LOGICAL, INTENT(IN) :: usecoldens
        !f2py intent(in) usecoldens
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints + 1, gridPoints, n_physics_params) :: physicsarray
        !f2py intent(in, out) physicsarray
        !f2py depend(gridPoints) physicsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints + 1, gridPoints, nspec) :: chemicalabunarray
        !f2py intent(in, out) chemicalabunarray
        !f2py depend(gridPoints) chemicalabunarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nReac) :: rateConstantsArray
        !f2py intent(in,out) rateConstantsArray
        !f2py depend(timePoints,gridPoints,nReac) rateConstantsArray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, nHeatingTerms) :: heatarray
        !f2py intent(in,out) heatarray
        !f2py depend(timePoints,gridPoints,nHeatingTerms) heatarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_DVODE_STATS) :: statsarray
        !f2py intent(in,out) statsarray
        !f2py depend(timePoints,gridPoints,N_DVODE_STATS) statsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, N_TOTAL_LEVELS) :: levelpopulationsarray
        !f2py intent(in,out) levelpopulationsarray
        !f2py depend(timePoints,gridPoints,N_TOTAL_LEVELS) levelpopulationsarray
        DOUBLE PRECISION, INTENT(INOUT), OPTIONAL, DIMENSION(timePoints+1, gridPoints, NCOOLANTS*N_SE_STATS_PER_COOLANT) :: sestatsarray
        !f2py intent(in,out) sestatsarray
        !f2py depend(timePoints,gridPoints,NCOOLANTS,N_SE_STATS_PER_COOLANT) sestatsarray
        DOUBLE PRECISION, OPTIONAL, DIMENSION(gridPoints, nspec) :: abundanceStart
        !f2py intent(in) abundanceStart
        !f2py depend(gridPoints, nspec) abundanceStart
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints) :: timegrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints) :: densgrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints) :: gastempgrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints) :: dusttempgrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints) :: radfieldgrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints) :: zetagrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints), OPTIONAL :: avgrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints), OPTIONAL :: nhgrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints), OPTIONAL :: nh2grid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints), OPTIONAL :: ncogrid
        DOUBLE PRECISION, INTENT(IN), DIMENSION(timePoints), OPTIONAL :: ncgrid
        !f2py  intent(in) timegrid,densgrid,gastempgrid,dusttempgrid,radfieldgrid,zetagrid,useav,avgrid
        !f2py  intent(in) nhgrid,nh2grid,ncogrid,ncgrid

        successFlag=0

        if (usecoldens) then
            call solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
                &updatePhysics,updateTargetTime,sublimation,returnArray,returnRateConstants,givestartabund,&
                &timepoints,physicsarray,chemicalabunarray,rateConstantsArray,heatarray,statsarray,levelpopulationsarray, sestatsarray, abundanceStart,&
                &timegrid,densgrid,gastempgrid,dusttempgrid,radfieldgrid,zetagrid,useav,avgrid,&
                &usecoldens,nhgrid,nh2grid,ncogrid,ncgrid)
        else
            call solveAbundances(dictionary, outSpeciesIn,successFlag,initializePhysics,&
                &updatePhysics,updateTargetTime,sublimation,returnArray,returnRateConstants,givestartabund,&
                &timepoints,physicsarray,chemicalabunarray,rateConstantsArray,heatarray,statsarray,levelpopulationsarray, sestatsarray, abundanceStart,&
                &timegrid,densgrid,gastempgrid,dusttempgrid,radfieldgrid,zetagrid,useav,avgrid,&
                &usecoldens)
        end if
        specname_out(:nspec) = specName
        IF ((ALLOCATED(outIndx)) .and. (successFlag .eq. 0)) THEN 
            abundance_out(1:SIZE(outIndx))=abund(outIndx,1)
        END IF 
    END SUBROUTINE postprocess

    SUBROUTINE get_rates(dictionary,abundancesIn,speciesIndx,rateIndxs,&
        &speciesRates,successFlag,transfer,swap,bulk_layers)
        !Given a species of interest, some parameters and abundances, this subroutine
        !returns the rate of all reactions that include that species plus some extra variables
        !to allow for the calculation of the rate of bulk/surface ice transfer.
        USE cloud_mod
        USE DEFAULTPARAMETERS
        ! USE constants, only : nspec
        !f2py integer, intent(aux) :: nspec
        CHARACTER(LEN=*):: dictionary
        DOUBLE PRECISION :: abundancesIn(nspec),speciesRates(nReac)
        DOUBLE PRECISION :: transfer,swap,bulk_layers
        INTEGER:: rateIndxs(nReac),speciesIndx, successFlag
        DOUBLE PRECISION :: ydot(nspec+1)
        INTEGER :: speci,bulk_version,surface_version
        real(dp) :: surfaceCoverage
        !f2py intent(in) dictionary,abundancesIn,speciesIndx,rateIndxs
        !f2py intent(out) speciesRates,successFlag,transfer,swap,bulk_layers
        ! INCLUDE 'defaultparameters.f90'

        CALL dictionaryParser(dictionary, "",successFlag)
        IF (successFlag .lt. 0) THEN
            WRITE(*,*) 'Error reading parameter dictionary'
            RETURN
        END IF
        CALL coreInitializePhysics(successFlag)
        CALL initializePhysics(successFlag)
        IF (successFlag .lt. 0) then
            WRITE(*,*) 'Error initializing physics'
            RETURN
        END IF

        CALL initializeChemistry(readAbunds, successFlag)
        IF (successFlag .lt. 0) RETURN
        dstep=1
        abund(:nspec,dstep)=abundancesIn(:nspec)
        abund(neq,dstep)=initialDens
        currentTime=0.0
        timeInYears=0.0

        targetTime=1.0d-7
        CALL updateChemistry(successFlag)

        CALL F(NEQ,currentTime,abund(:,dstep),ydot)

        speciesRates=rate(rateIndxs)

        IF ((specname(speciesIndx)(1:1) .eq. "#") .or.&
        & (specname(speciesIndx)(1:1) .eq. "@")) THEN
            DO speci=1,nspec
                IF (specname(speci) .eq. "@"//specname(speciesIndx)(2:)) bulk_version=speci
                IF (specname(speci) .eq. "#"//specname(speciesIndx)(2:)) surface_version=speci
            END DO
            IF (SURFGROWTHUNCORRECTED .lt. 0) THEN
                surfaceCoverage = MIN(1.0, safeBulk/safeMantle)
                transfer=SURFGROWTHUNCORRECTED*surfaceCoverage*abund(bulk_version,1)/safeBulk
            ELSE
                surfaceCoverage = bulkGainFromMantleBuildUp()
                transfer=SURFGROWTHUNCORRECTED*surfaceCoverage*abund(surface_version,1)
            END If
            swap=totalSwap
            bulk_layers=bulkLayersReciprocal
        ELSE
            swap=0.0
            transfer=0.0
            bulk_layers=0.0
        END IF

    END SUBROUTINE get_rates

    SUBROUTINE get_odes(dictionary,abundancesIn,ratesOut)
        !Obtain the ODE values for some given parameters and abundances.
        !Essentially runs one time step of solveAbundances  then calls the ODE subroutine (F)
        USE cloud_mod
        use f2py_constants
        !f2py integer, intent(aux) :: nspec
        CHARACTER(LEN=*) :: dictionary
        DOUBLE PRECISION :: abundancesIn(nspec),ratesOut(nspec+1)
        INTEGER :: successFlag
        !f2py intent(in) :: dictionary, abundancesIn
        !f2py intent(out) :: ratesOut
        ! INCLUDE 'defaultparameters.f90'
        CALL dictionaryParser(dictionary, "",successFlag)

        call coreInitializePhysics(successFlag)
        CALL initializePhysics(successFlag)
        IF (successFlag .lt. 0) then
            WRITE(*,*) 'Error initializing physics'
            RETURN
        END IF

        CALL initializeChemistry(readAbunds, successFlag)
        IF (successFlag .lt. 0) RETURN
        dstep=1
        abund(:nspec,dstep)=abundancesIn(:nspec)
        abund(neq,dstep)=initialDens
        currentTime=0.0
        timeInYears=0.0
        targetTime=1.0d-7
        CALL updateChemistry(successFlag)
        CALL F(NEQ,currentTime,abund(:,dstep),ratesOut(:NEQ))
    END SUBROUTINE get_odes

    SUBROUTINE solveAbundances(dictionary,outSpeciesIn,successFlag,modelInitializePhysics,&
            &modelUpdatePhysics,updateTargetTime, sublimation, returnArray, returnRateConstants,givestartabund,&
            &timePoints, physicsarray, chemicalabunarray,rateConstantsArray,heatarray,statsarray,levelpopulationsarray,sestatsarray,abundanceStart,&
            &timegrid,densgrid,gtempgrid,dtempgrid,radgrid,zetagrid,useav,avgrid,usecoldens,nhgrid,nh2grid,ncogrid,ncgrid)
        USE, INTRINSIC :: iso_c_binding, ONLY: C_NULL_PTR, C_INT
        ! Core UCLCHEM routine. Solves the chemical equations for a given set of parameters through time
        ! for a specified physical model.
        ! Change behavior of physics by sending different subroutine arguments - hence the need for model subroutines above
        ! dictionary - the parameter dictionary string representing a python dictionary
        ! outSpeciesIn - the species to output to separate file
        ! successFlag - Integer to indicate whether code completed successfully
        ! modelInitializePhysics - subroutine to initialize physics from a physics module
        ! modelUpdatePhysics - subroutine to update physics from a physics module
        ! updateTargetTime - subroutine to update the target time from a physics module
        ! sublimation - subroutine allowing physics module to directly modify abundances once per time step.
        ! returnArray - boolean on whether arrays will be returned
        ! givestartabund -  boolean on whether starting abundances were given
        ! gridPoints - number of points uclchem should simulate
        ! physicsarray - array to be filled with physical information for each timestep (optional)
        ! chemicalabunarray - array to be filled with chemical abundances for each timestep (optional)
        ! abundanceStart - array containing starting chemical conditions (optional)
        ! USE constants, only : nspec
        !f2py integer, intent(aux) :: nspec, nHeatingTerms, NCOOLANTS, N_DVODE_STATS, N_TOTAL_LEVELS, N_SE_STATS_PER_COOLANT
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        EXTERNAL modelInitializePhysics,updateTargetTime,modelUpdatePhysics,sublimation
        INTEGER, INTENT(OUT) :: successFlag
        LOGICAL :: returnArray, givestartabund, returnRateConstants
        INTEGER :: dtime, timePoints, dtime_local
        REAL(dp) :: initialTime, outermost_stop_time
        LOGICAL :: parcelDone, outermost_stopped
        ! Arrays needed to work return physics in memory mode
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: physicsarray
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: chemicalabunarray
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: rateConstantsArray
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: heatarray
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: statsarray
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: levelpopulationsarray
        DOUBLE PRECISION, DIMENSION(:, :, :), OPTIONAL :: sestatsarray
        DOUBLE PRECISION, DIMENSION(:, :), OPTIONAL :: abundanceStart
        ! Arrays needed to work with custom density/temperature profiles
        !  &timegrid,densgrid,gastempgrid,dusttempgrid,nhgrid,nh2grid,ncogrodi,ncgrid)
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: timegrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: densgrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: gtempgrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: dtempgrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: radgrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: avgrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: zetagrid
        LOGICAL, OPTIONAL :: useav
        LOGICAL, OPTIONAL :: usecoldens
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: nhgrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: nh2grid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: ncogrid
        DOUBLE PRECISION, DIMENSION(:), OPTIONAL :: ncgrid
        INTEGER(C_INT) :: flush_rc
        INTERFACE
            INTEGER(C_INT) FUNCTION c_fflush(stream) &
                    BIND(C, name="fflush")
                USE, INTRINSIC :: iso_c_binding, &
                    ONLY: C_INT, C_PTR
                TYPE(C_PTR), VALUE :: stream
            END FUNCTION c_fflush
        END INTERFACE
        successFlag=0
        ! Debug: Print array dimensions
        ! Set variables to default values
        ! INCLUDE 'defaultparameters.f90'
        !Read input parameters from the dictionary
        CALL dictionaryParser(dictionary, outSpeciesIn, successFlag)
        IF (successFlag .lt. 0) THEN
            successFlag=PARAMETER_READ_ERROR
            WRITE(*,*) 'Error reading parameter dictionary'
            RETURN
        END IF
        dstep=1
        currentTime=0.0
        timeInYears=0.0
        IF (returnArray) THEN
            ! Fix to make sure that running in memory mode after running in file mode works correctly
            readAbunds=.False.
            writeAbunds=.False.
        ELSE
            CALL fileSetup
        END IF
        !Initialize core physics first then model specific
        !This allows model to overrule changes made by core
        CALL coreInitializePhysics(successFlag)
        IF (successFlag .lt. 0) then
            successFlag=PHYSICS_INIT_ERROR
            WRITE(*,*) 'Error initializing physics'
            RETURN
        END IF

        if (present(timegrid)) then
            if (usecoldens) then
                call modelInitializePhysics(successflag, timegrid,densgrid,radgrid,zetagrid,gtempgrid,&
                &dtempgrid,useav,avgrid,usecoldens,timepoints,nhgrid,nh2grid,ncogrid,ncgrid)
            else 
                call modelInitializePhysics(successflag, timegrid,densgrid,radgrid,zetagrid,gtempgrid,&
                &dtempgrid,useav,avgrid,usecoldens,timepoints) 
            end if
        else 
            call modelInitializePhysics(successFlag)
        end if 
        IF (successFlag .lt. 0) then
            successFlag=PHYSICS_INIT_ERROR
            WRITE(*,*) 'Error initializing physics'
            RETURN
        END IF

        ! Initialize the chemistry
        CALL initializeChemistry(readAbunds, successFlag)
        IF (successFlag .lt. 0) RETURN
        IF (returnArray .AND. givestartabund) THEN
            ! In case we have custom abundances, set them here
            IF (enable_radiative_transfer .AND. points.gt.1) THEN
                DO l=points,1,-1
                    abund(:nspec,l) = abundanceStart(l, :nspec)
                END DO
            ELSE
                DO l=1,points
                    abund(:nspec,l) = abundanceStart(l, :nspec)
                END DO
            END IF
        ELSE
            ! Else just use the default readInputAbunds routine:
            CALL readInputAbunds !this won't do anything if no abundLoadFile was in input
        END IF
        ! Set conservation baseline after all starting abundances are loaded.
        ! For 1D RT the per-parcel baseline is updated inside the parcel loop below.
        IF (.NOT. (enable_radiative_transfer .AND. points.gt.1)) CALL setConservationBaseline()
        !CALL simpleDebug("Initialized")

        dstep = 1
        dtime = 0  ! Start at 0 so first loop iteration writes to dtime=1
        ! Set timeInYears for consistency
        timeInYears = currentTime / SECONDS_PER_YEAR
        ! Don't call output here - let the first loop iteration handle it
        ! This avoids duplicate output at t=0

        ! One-time setup for the (points, time) loop order used in 1D RT models
        IF (enable_radiative_transfer .AND. points.gt.1) THEN
            IF (ALLOCATED(coldens_history)) DEALLOCATE(coldens_history)
            ALLOCATE(coldens_history(timepoints+1))
            coldens_history = 0.0_dp
            initialTime = currentTime
            outermost_stop_time = finalTime * SECONDS_PER_YEAR
            outermost_stopped = .FALSE.
        END IF

        IF (enable_radiative_transfer .AND. points.gt.1) THEN
            ! -- (points outer, time inner) loop -------------------------------------
            ! Processes each spatial parcel through its full time evolution before
            ! moving inward. DVODE retains BDF history (ISTATE=2) across all timesteps
            ! for a given parcel. coldens_history stores coldens(dstep+1, dtime) so the
            ! edge-to-core AV accumulation is reproduced exactly without approximation.
            DO dstep=points,1,-1

                ! -- per-parcel reset ------------------------------------------------
                currentTime  = initialTime
                timeInYears  = initialTime / SECONDS_PER_YEAR
                dtime_local  = 0
                parcelDone   = .FALSE.
                coolant_levpop_force_recompute = .TRUE.

                IF (givestartabund) abund(:nspec, dstep) = abundanceStart(dstep, :nspec)
                CALL resetConservationBaselineForPoint(dstep)
                CALL resetDVODEForNewPoint()

                ! Outermost shell has no outer neighbor; initialize to zero
                IF (dstep .eq. points) outer_coldens_for_current_step = 0.0_dp

                ! -- time integration for this parcel --------------------------------
                DO WHILE ((successFlag .eq. 0) .AND. (timeInYears < finalTime) .AND. (.NOT. parcelDone))

                    ! Modes 1 & 2: stop inner parcels when the outermost parcel stopped
                    IF ((parcelStoppingMode .eq. 1 .OR. parcelStoppingMode .eq. 2) &
                            .AND. outermost_stopped .AND. dstep .lt. points) THEN
                        IF (currentTime .ge. outermost_stop_time) EXIT
                    END IF

                    dtime_local    = dtime_local + 1
                    currentTimeold = currentTime
                    CALL updateTargetTime
                    coolant_levpop_force_recompute = .TRUE.
                    IF (targetTime/SECONDS_PER_YEAR .gt. finalTime) EXIT

                    ! Freefall stopping logic
                    IF (freefall .AND. density(dstep) .ge. density_max(dstep)) THEN
                        SELECT CASE (parcelStoppingMode)
                            CASE (0)
                                density(dstep) = density_max(dstep)
                            CASE (1)
                                IF (dstep .eq. points) THEN
                                    outermost_stop_time = currentTime
                                    outermost_stopped   = .TRUE.
                                END IF
                                density(dstep) = density_max(dstep)
                            CASE (2)
                                IF (dstep .eq. points) THEN
                                    outermost_stop_time = currentTime
                                    outermost_stopped   = .TRUE.
                                    parcelDone = .TRUE.    ! outermost exits at its own freefall time
                                ELSE
                                    density(dstep) = density_max(dstep)  ! inner: cap density, keep running
                                END IF
                            CASE DEFAULT
                                IF (dstep .eq. points) THEN
                                    outermost_stop_time = currentTime
                                    outermost_stopped   = .TRUE.
                                END IF
                                density(dstep) = density_max(dstep)
                        END SELECT
                    END IF

                    IF (writeTimestepInfo) THEN
                        WRITE(*,'(A,I3,A,ES10.2,A,ES10.2,A,F9.1,A,F9.1,A,ES10.2,A,ES10.2,A,ES10.2)') &
                            'p:', dstep, &
                            't:', currentTimeold/SECONDS_PER_YEAR, &
                            ' dT:', dvode_rstats(11)/SECONDS_PER_YEAR, &
                            ' Tg:', gasTemp(dstep), &
                            ' Td:', dustTemp(dstep), &
                            ' nH:', density(dstep), &
                            ' G0:', radfield, &
                            ' z:', zeta
                        FLUSH(6)
                        flush_rc = c_fflush(C_NULL_PTR)
                    END IF

                    IF (.NOT. parcelDone) THEN
                        ! Load outer neighbor's coldens at this timestep for the AV accumulation
                        IF (dstep .lt. points) &
                            outer_coldens_for_current_step = coldens_history(dtime_local)

                        CALL updateChemistry(successFlag, statsarray, timePoints+1, dtime_local)
                        IF (successFlag .lt. 0) THEN
                            WRITE(*,*) 'Error updating chemistry'
                            RETURN
                        END IF
                        IF (coolant_error_flag .ne. 0) THEN
                            WRITE(*,*) 'Coolant error: ', TRIM(coolant_error_message)
                            successFlag = coolant_error_flag
                            coolant_error_flag = 0
                            RETURN
                        END IF
                        timeInYears = targetTime / SECONDS_PER_YEAR

                        CALL coreUpdatePhysics
                        CALL modelUpdatePhysics
                        IF (postprocess_error .NE. 0) THEN
                            successFlag = PHYSICS_UPDATE_ERROR
                            WRITE(*,*) 'ERROR: postprocess physics update failed with code=', postprocess_error
                            RETURN
                        END IF

                        ! Store this parcel's coldens for the next inner parcel to use
                        coldens_history(dtime_local) = coldens(dstep)

                        CALL sublimation(abund, points)
                    END IF

                    IF (returnArray) THEN
                        CALL output(returnArray, returnRateConstants, successflag, physicsarray, &
                            chemicalabunarray, rateConstantsArray, heatarray, statsarray, &
                            levelpopulationsarray, sestatsarray, dtime_local, timepoints)
                    ELSE
                        CALL output(returnArray, returnRateConstants, successflag)
                    END IF

                    IF (parcelDone) EXIT

                END DO  ! inner time loop

            END DO  ! outer parcel loop

        ELSE
            ! -- non-RT path: original (time outer, points inner) loop ----------------
            DO WHILE ((successFlag .eq. 0) .and. (timeInYears < finalTime))
                dtime = dtime + 1
                currentTimeold=currentTime
                CALL updateTargetTime
                coolant_levpop_force_recompute = .TRUE.
                IF ((.not. endAtFinalDensity) .and. (targetTime/SECONDS_PER_YEAR .gt. finalTime)) THEN
                    EXIT
                END IF

                ! Exit loop if density exceeds finalDens (when using density-based stopping)
                IF ((parcelStoppingMode .ne. 0) .and. (density(1) .ge. finalDens)) THEN
                    EXIT
                END IF
                !loop over parcels, counting from center out to edge of cloud
                DO dstep=1,points
                    !reset time if this isn't first depth point
                    currentTime=currentTimeold

                    IF (writeTimestepInfo) THEN
                        WRITE(*,'(A,ES10.2,A,ES10.2,A,F9.1,A,F9.1,A,ES10.2,A,ES10.2,A,ES10.2)') &
                            't:', currentTimeold/SECONDS_PER_YEAR, &
                            ' dT:', dvode_rstats(11)/SECONDS_PER_YEAR, &
                            ' Tg:', gasTemp(1), &
                            ' Td:', dustTemp(1), &
                            ' nH:', density(1), &
                            ' G0:', radfield, &
                            ' z:', zeta
                        FLUSH(6)
                        flush_rc = c_fflush(C_NULL_PTR)
                    END IF
                    CALL updateChemistry(successFlag, statsarray, timePoints+1, dtime)
                    IF (successFlag .lt. 0) THEN
                        write(*,*) 'Error updating chemistry'
                        RETURN
                    END IF
                    IF (coolant_error_flag .ne. 0) THEN
                        WRITE(*,*) 'Coolant error: ', TRIM(coolant_error_message)
                        successFlag = coolant_error_flag
                        coolant_error_flag = 0
                        RETURN
                    END IF
                    timeInYears= targetTime/SECONDS_PER_YEAR

                    call coreUpdatePhysics
                    call modelUpdatePhysics
                    IF (postprocess_error .NE. 0) THEN
                        successFlag = PHYSICS_UPDATE_ERROR
                        WRITE(*,*) 'ERROR: postprocess physics update failed with code=', postprocess_error
                        RETURN
                    END IF
                    CALL sublimation(abund, points)
                    IF (returnArray) THEN
                        CALL output(returnArray, returnRateConstants, successFlag, physicsarray, chemicalabunarray, rateConstantsArray,&
                        &heatarray, statsarray, levelpopulationsarray, sestatsarray, dtime, timepoints)
                    ELSE
                        CALL output(returnArray, returnRateConstants, successFlag)
                    END IF
                END DO
            END DO
        END IF
        IF (.NOT. returnArray) THEN
            CALL finalOutput
            CALL closeFiles
        END IF
        ! IF (ALLOCATED(outIndx)) DEALLOCATE(outIndx)
        ! IF (ALLOCATED(outSpecies)) DEALLOCATE(outSpecies)
    END SUBROUTINE solveAbundances

    SUBROUTINE dictionaryParser(dictionary, outSpeciesIn,successFlag)
        !Reads the input parameters from a string containing a python dictionary/JSON format
        !set of parameter names and values.
        !dictionary - lowercase keys matching the names of the parameters in the select case below
        !OutSpeciesIn - string containing the species to output
        !successFlag - integer flag to indicate success
        
        !f2py integer, intent(aux) :: nspec
        CHARACTER(LEN=*) :: dictionary, outSpeciesIn
        INTEGER, INTENT(OUT) :: successFlag
        INTEGER, ALLOCATABLE, DIMENSION(:) :: locations
        LOGICAL :: ChemicalDuplicateCheck, isOpen
        INTEGER :: posStart, posEnd, whileInteger,inputindx
        CHARACTER(LEN=100) :: inputParameter, inputValue
        CHARACTER(256) :: fullPath

        close(10)
        close(11)
        close(7)
        INQUIRE(unit=15, opened=isOpen)
        IF (isOpen) close(15)
        INQUIRE(unit=16, opened=isOpen)
        IF (isOpen) close(16)
        
        !always deallocate these so that if user didn't specify them,
        ! they don't remain from previous run
        IF (ALLOCATED(outIndx)) DEALLOCATE(outIndx)
        IF (ALLOCATED(outSpecies)) DEALLOCATE(outSpecies)

        !All reads use IOSTAT which will change successFlag from 0 if an error occurs
        !so set zero and check for non-zero each loop.
        successFlag=0

        whileInteger = 0

        posStart = scan(dictionary, '{')
        DO WHILE (whileInteger .NE. 1)
            posEnd = scan(dictionary, ':')
            inputParameter = dictionary(posStart+2:posEnd-2)
            dictionary = dictionary(posEnd:)
            posStart = scan(dictionary, ' ')
            IF (scan(dictionary, ',') .EQ. 0) THEN
                posEnd = scan(dictionary, '}')
                whileInteger = 1
            ELSE
                posEnd = scan(dictionary, ',')
            END IF
            inputValue = dictionary(posStart+1:posEnd-1)

            SELECT CASE (inputParameter)
                CASE('alpha')
                    !To provide alphas, set keyword alpha in inputdictionary with a dictionary value
                    !that dictionary should be index:value pairs for the alpha array    
                    posStart=scan(dictionary,'{')
                    posEnd=scan(dictionary,'}')
                    CALL coefficientParser(dictionary(posStart+1:posEnd),alpha)
                CASE('beta')
                    !To provide alphas, set keyword alpha in inputdictionary with a dictionary value
                    !that dictionary should be index:value pairs for the alpha array    
                    posStart=scan(dictionary,'{')
                    posEnd=scan(dictionary,'}')
                    CALL coefficientParser(dictionary(posStart+1:posEnd),beta)
                CASE('gamma')
                    !To provide alphas, set keyword alpha in inputdictionary with a dictionary value
                    !that dictionary should be index:value pairs for the alpha array    
                    posStart=scan(dictionary,'{')
                    posEnd=scan(dictionary,'}')
                    CALL coefficientParser(dictionary(posStart+1:posEnd),gama)
                CASE('initialtemp')
                    READ(inputValue,*,iostat=successFlag) initialTemp
                CASE('initialdens')
                    READ(inputValue,*,iostat=successFlag) initialDens
                CASE('finaldens')
                    READ(inputValue,*,iostat=successFlag) finalDens
                CASE('currenttime')
                    READ(inputValue,*,iostat=successFlag) currentTime
                CASE('finaltime')
                    READ(inputValue,*,iostat=successFlag) finalTime
                CASE('enable_radiative_transfer')
                    READ(inputValue,*,iostat=successFlag) enable_radiative_transfer
                CASE('radfield')
                    READ(inputValue,*,iostat=successFlag) radfield
                CASE('zeta')
                    READ(inputValue,*,iostat=successFlag) zeta
                CASE('freezefactor')
                    READ(inputValue,*,iostat=successFlag) freezeFactor
                CASE('rout')
                    READ(inputValue,*,iostat=successFlag) rout
                CASE('rin')
                    READ(inputValue,*,iostat=successFlag) rin
                CASE('baseav')
                    READ(inputValue,*,iostat=successFlag) baseAv
                CASE('points')
                    READ(inputValue,*,iostat=successFlag) points
                CASE('bm0')
                    READ(inputValue,*,iostat=successFlag) bm0
                CASE('density_scale_radius')
                    READ(inputValue,*,iostat=successFlag) density_scale_radius
                CASE('density_power_index')
                    READ(inputValue,*,iostat=successFlag) density_power_index
                CASE('lum_star')
                    READ(inputValue,*,iostat=successFlag) lum_star
                CASE('temp_star')
                    READ(inputValue,*,iostat=successFlag) temp_star
                CASE('parcelstoppingmode')
                    READ(inputValue,*,iostat=successFlag) parcelStoppingMode
                CASE('endatfinaldensity')
                    Read(inputValue,*,iostat=successFlag) endAtFinalDensity
                CASE('freefall')
                    READ(inputValue,*,iostat=successFlag) freefall
                CASE('freefallfactor')
                    READ(inputValue,*,iostat=successFlag) freefallFactor
                CASE('desorb')
                    READ(inputValue,*,iostat=successFlag) desorb
                CASE('h2desorb')
                    READ(inputValue,*,iostat=successFlag) h2desorb
                CASE('crdesorb')
                    READ(inputValue,*,iostat=successFlag) crdesorb
                CASE('uvdesorb')
                    READ(inputValue,*,iostat=successFlag) uvdesorb
                CASE('chemdesorb')
                    READ(inputValue,*,iostat=successFlag) chemdesorb
                CASE('thermdesorb')
                    READ(inputValue,*,iostat=successFlag) thermdesorb
                CASE('instantsublimation')
                    READ(inputValue,*,iostat=successFlag) instantSublimation
                CASE('cosmicrayattenuation')
                    READ(inputValue,*,iostat=successFlag) cosmicRayAttenuation
                CASE('ionmodel')
                    READ(inputValue,*,iostat=successFlag) ionModel
                CASE('improvedh2crpdissociation')
                    READ(inputValue,*,iostat=successFlag) improvedH2CRPDissociation
                CASE('ion')
                    READ(inputValue,*,iostat=successFlag) ion
                CASE('fhe')
                    READ(inputValue,*,iostat=successFlag) fhe
                CASE('fc')
                    READ(inputValue,*,iostat=successFlag) fc
                CASE('fo')
                    READ(inputValue,*,iostat=successFlag) fo
                CASE('fn')
                    READ(inputValue,*,iostat=successFlag) fn
                CASE('fs')
                    READ(inputValue,*,iostat=successFlag) fs
                CASE('fmg')
                    READ(inputValue,*,iostat=successFlag) fmg
                CASE('fsi')
                    READ(inputValue,*,iostat=successFlag) fsi
                CASE('fcl')
                    READ(inputValue,*,iostat=successFlag) fcl
                CASE('fp')
                    READ(inputValue,*,iostat=successFlag) fp
                CASE('ffe')
                    READ(inputValue,*,iostat=successFlag) ffe
                CASE('ff')
                    READ(inputValue,*,iostat=successFlag) ff
                CASE('fd')
                    READ(inputValue,*,iostat=successFlag) fd
                CASE('fli')
                    READ(inputValue,*,iostat=successFlag) fli
                CASE('fna')
                    READ(inputValue,*,iostat=successFlag) fna
                CASE('fpah')
                    READ(inputValue,*,iostat=successFlag) fpah
                CASE('f15n')
                    READ(inputValue,*,iostat=successFlag) f15n
                CASE('f13c')
                    READ(inputValue,*,iostat=successFlag) f13c
                CASE('f18o')
                    READ(inputValue,*,iostat=successFlag) f18o
                CASE('outspecies')
                    READ(inputValue,*,iostat=successFlag) nout
                    ALLOCATE(outIndx(nout))
                    ALLOCATE(outSpecies(nout))
                    IF (outSpeciesIn .eq. "") THEN
                        write(*,*) "Outspecies parameter set but no outspecies string given"
                        write(*,*) "general(parameter_dict,outSpeciesIn) requires a delimited string of species names"
                        write(*,*) "if outSpecies or columnFlag is set in the parameter dictionary"
                        successFlag=-1
                        RETURN
                    ELSE
                        READ(outSpeciesIn,*, END=22) outSpecies
                        IF (outSpeciesIn .eq. "") THEN
22                              write(*,*) "mismatch between outSpeciesIn and number given in dictionary"
                            write(*,*) "Number:",nout
                            write(*,*) "Species list:",outSpeciesIn
                            successFlag=-1
                            RETURN
                        END IF
                    END IF
                    !assign array indices for important species to the integers used to store them.
                    DO i=1,nspec
                        DO j=1,nout
                            IF (specname(i).eq.outSpecies(j)) outIndx(j)=i
                        END DO
                    END DO
                CASE('writestep')
                    READ(inputValue,*,iostat=successFlag) writeStep
                CASE('writetimestepinfo','writetimestep')
                    READ(inputValue,*,iostat=successFlag) writeTimestepInfo
                CASE('heatingFlag', 'heatingflag')
                    READ(inputValue,*,iostat=successFlag) heatingFlag
                CASE('ebmaxh2')
                    READ(inputValue,*,iostat=successFlag) ebmaxh2
                CASE('epsilon')
                    READ(inputValue,*,iostat=successFlag) epsilon
                CASE('uvcreff')
                    READ(inputValue,*,iostat=successFlag) uvcreff
                CASE('ebmaxcr')
                    READ(inputValue,*,iostat=successFlag) ebmaxcr
                CASE('phi')
                    READ(inputValue,*,iostat=successFlag) phi
                CASE('ebmaxuvcr')
                    READ(inputValue,*,iostat=successFlag) ebmaxuvcr
                CASE('uv_yield')
                    READ(inputValue,*,iostat=successFlag) uv_yield
                CASE('metallicity')
                    READ(inputValue,*,iostat=successFlag) metallicity
                CASE('omega')
                    READ(inputValue,*,iostat=successFlag) omega
                CASE('difftobindratio')
                    READ(inputValue,*,iostat=successFlag) diffToBindRatio
                CASE('min_desorption_rate')
                    READ(inputValue,*,iostat=successFlag) min_desorption_rate
                CASE('max_desorption_rate_factor')
                    READ(inputValue,*,iostat=successFlag) max_desorption_rate_factor
                CASE('min_desorption_rate_cap')
                    READ(inputValue,*,iostat=successFlag) min_desorption_rate_cap
                CASE('max_desorption_rate_cap')
                    READ(inputValue,*,iostat=successFlag) max_desorption_rate_cap
                CASE('enforcechargeconservation')
                    READ(inputValue,*,iostat=successFlag) enforceChargeConservation
                CASE('reltol')
                    READ(inputValue,*,iostat=successFlag) reltol
                CASE('abstol_factor')
                    READ(inputValue,*,iostat=successFlag) abstol_factor
                CASE('abstol_min')
                    READ(inputValue,*,iostat=successFlag) abstol_min
                CASE('abstol_ice_factor')
                    READ(inputValue,*,iostat=successFlag) abstol_ice_factor
                CASE('abstol_ice_min')
                    READ(inputValue,*,iostat=successFlag) abstol_ice_min
                CASE('negative_abundance_tol')
                    READ(inputValue,*,iostat=successFlag) negative_abundance_tol
                CASE('runtime_conservation_tolerance')
                    READ(inputValue,*,iostat=successFlag) runtime_conservation_tolerance
                CASE('reltol_phys')
                    READ(inputValue,*,iostat=successFlag) reltol_phys
                CASE('abstol_phys_factor')
                    READ(inputValue,*,iostat=successFlag) abstol_phys_factor
                CASE('abstol_t_min')
                    READ(inputValue,*,iostat=successFlag) abstol_T_min
                CASE('abstol_nh_min')
                    READ(inputValue,*,iostat=successFlag) abstol_nH_min
                ! CASE('jacobian')
                !     READ(inputValue,*) jacobian
                CASE('abundsavefile')
                    READ(inputValue,*,iostat=successFlag) abundSaveFile
                    abundSaveFile = TRIM(abundSaveFile)
                    if (LEN(abundSaveFile) .gt. 0) then
                        open(abundSaveID,file=abundSaveFile,status='unknown')
                    end if
                CASE('abundloadfile')
                    READ(inputValue,*,iostat=successFlag) abundLoadFile
                    abundLoadFile = TRIM(abundLoadFile)
                    if (LEN(abundLoadFile) .gt. 0) then
                        open(abundLoadID,file=abundLoadFile,status='old')
                    end if
                CASE('outputfile')
                    READ(inputValue,*,iostat=successFlag) outputFile
                    outputFile = trim(outputFile)
                    fullOutput=.True.
                    if (LEN(outputFile) .gt. 0) then
                        open(outputId,file=outputFile,status='unknown',iostat=successFlag)
                    end if
                    
                    IF (successFlag .ne. 0) THEN
                        write(*,*) "An error occurred when opening the output file!"//&
                                        & NEW_LINE('A')//&
                                    &" The failed file was ",outputFile&
                                    &, NEW_LINE('A')//"A common error is that the directory doesn't exist"&
                                    &//NEW_LINE('A')//"************************"
                        successFlag=-1
                        RETURN
                    END IF
                CASE('rateConstantFile')
                    READ(inputValue,*,iostat=successFlag) rateConstantFile
                    rateConstantFile = trim(rateConstantFile)
                    if ((LEN(ratesFile) .gt. 0) .and. (.not. storeRatesComputation))then
                        WRITE(*,*) "Error: a ratesFile was specified as output, but fortran was"//&
                        & NEW_LINE('A')//&
                        &"compiled without the rate storage option, please enable `enable_rates_storage` "//&
                        & NEW_LINE('A')//"in the Makerates compilation process."
                    end if
                    open(rateConstantId,file=rateConstantFile,status='unknown',iostat=successFlag)
                    IF (successFlag .ne. 0) THEN
                        write(*,*) "An error occurred when opening the rate file!"//&
                                        & NEW_LINE('A')//&
                                    &" The failed file was ",rateConstantFile&
                                    &, NEW_LINE('A')//"A common error is that the directory doesn't exist"&
                                    &//NEW_LINE('A')//"************************"
                        successFlag=-1
                        RETURN
                    END IF
                CASE('ratesFile')
                    READ(inputValue,*,iostat=successFlag) ratesFile
                    ratesFile = trim(ratesFile)
                    if ((LEN(ratesFile) .gt. 0) .and. (.not. storeRatesComputation))then
                        WRITE(*,*) "Error: a ratesFile was specified as output, but fortran was"//&
                        & NEW_LINE('A')//&
                        &"compiled without the rate storage option, please enable `enable_rates_storage` "//&
                        & NEW_LINE('A')//"in the Makerates compilation process."
                    end if
                    open(ratesId,file=ratesFile,status='unknown',iostat=successFlag)
                    IF (successFlag .ne. 0) THEN
                        write(*,*) "An error occurred when opening the rate file!"//&
                                        & NEW_LINE('A')//&
                                    &" The failed file was ",ratesFile&
                                    &, NEW_LINE('A')//"A common error is that the directory doesn't exist"&
                                    &//NEW_LINE('A')//"************************"
                        successFlag=-1
                        RETURN
                    END IF
                CASE('heatingfile')
                    READ(inputValue,*,iostat=successFlag) heatingFile
                    heatingFile = trim(heatingFile)
                    open(heatingId,file=heatingFile,status='unknown',iostat=successFlag)
                    IF (successFlag .ne. 0) THEN
                        write(*,*) "An error occurred when opening the heating rate file!"//&
                                        & NEW_LINE('A')//&
                                    &" The failed file was ",heatingFile&
                                    &, NEW_LINE('A')//"A common error is that the directory doesn't exist"&
                                    &//NEW_LINE('A')//"************************"
                        successFlag=-1
                        RETURN
                    END IF
                CASE('columnfile')
                    IF (trim(outSpeciesIn) .NE. '' ) THEN
                        columnOutput=.True.
                        
                        READ(inputValue,*,iostat=successFlag) columnFile
                        columnFile = trim(columnFile)
                        if (LEN(columnFile) .gt. 0) then
                            open(columnId,file=columnFile,status='unknown')
                        end if
                    ELSE
                        WRITE(*,*) "Error in output species. No species were given but a column file was given."
                        WRITE(*,*) "columnated output requires output species to be chosen."
                        successFlag=-1
                        RETURN
                     END IF
                ! Additional parameters for postprocessing mode
                CASE('fh')
                   READ(inputValue,*,iostat=successFlag) fh
                CASE('mxstep')
                   READ(inputValue,*,iostat=successFlag) MXSTEP
                CASE('h2encounterdesorption')
                   READ(inputValue,*,iostat=successFlag) h2EncounterDesorption
                CASE('hencounterdesorption')
                   READ(inputValue,*,iostat=successFlag) hEncounterDesorption
                CASE('edendothermicityfactor')
                   READ(inputValue,*,iostat=successFlag) EDEndothermicityFactor
                CASE('h2stickingcoeffbyh2coverage')
                   READ(inputValue,*,iostat=successFlag) h2StickingCoeffByh2Coverage
                CASE('hstickingcoeffbyh2coverage')
                   READ(inputValue,*,iostat=successFlag) hStickingCoeffByh2Coverage
                CASE('hdiffusionbarrier')
                   READ(inputValue,*,iostat=successFlag) HdiffusionBarrier
                CASE('usecustomdiffusionbarriers')
                   READ(inputValue,*,iostat=successFlag) useCustomDiffusionBarriers
                CASE('separatediffanddesorbprefactor')
                   READ(inputValue,*,iostat=successFlag) separateDiffAndDesorbPrefactor
                CASE('usetstprefactors')
                   READ(inputValue,*,iostat=successFlag) useTSTprefactors
                CASE('usecustomprefactors')
                   READ(inputValue,*,iostat=successFlag) useCustomPrefactors
                CASE('useminissaleicechemdesefficiency')
                   READ(inputValue,*,iostat=successFlag) useMinissaleIceChemdesEfficiency
                CASE('freq_rel_tol')
                   READ(inputValue,*,iostat=successFlag) freq_rel_tol
                CASE('pop_rel_tol')
                   READ(inputValue,*,iostat=successFlag) pop_rel_tol
                CASE('maxgraintemp')
                   READ(inputValue,*,iostat=successFlag) maxGrainTemp
                CASE('parameterizeh2form')
                   READ(inputValue,*,iostat=successFlag) parameterizeH2Form
                CASE('heating_temp_abstol')
                   READ(inputValue,*,iostat=successFlag) heating_temp_abstol
                CASE('heating_temp_reltol')
                   READ(inputValue,*,iostat=successFlag) heating_temp_reltol
                CASE('solver_mode')
                   READ(inputValue,*,iostat=successFlag) solverMode
                CASE('log_change_threshold')
                   READ(inputValue,*,iostat=successFlag) logChangeThreshold
                ! CASE('trajecfile')
                !    READ(inputValue,*,iostat=successFlag) trajecfile
                CASE DEFAULT
                    WRITE(*,*) "Problem with given parameter: '", trim(inputParameter), "'."
                    WRITE(*,*) "This is either not supported yet, or invalid."
                    successFlag=-1
                    RETURN
            END SELECT
            dictionary = dictionary(posEnd:)
            IF (SCAN(dictionary,',') .eq. 0) whileInteger=1

            !check for failure
            IF (successFlag .ne. 0) THEN
                WRITE(*,*) "Error reading ",inputParameter
                write(*,*) "This is usually due to wrong type."
                successFlag=PARAMETER_READ_ERROR
                RETURN
            END IF
        END DO
    END SUBROUTINE dictionaryParser

    SUBROUTINE coefficientParser(coeffDictString,coeffArray)
        !Similar to dictionaryParser, it reads a python dictionary
        !however, it's intended to read pairs of reaction indices and coefficient values
        !for the alpha, beta, and gama arrays.
        ! No return value, just modifies the coeffArray
        CHARACTER(LEN=*) :: coeffDictString
        REAL(dp), INTENT(INOUT) :: coeffArray(*)
        INTEGER :: inputIndx,posStart,posEnd
        CHARACTER(LEN=100) :: inputValue
        LOGICAL :: continue_flag
        
        continue_flag=.True.
        DO WHILE (continue_flag)
            !substring containing integer key
            posStart=1
            posEnd=SCAN(coeffDictString,':')
            !read it into index integer
            READ(coeffDictString(posStart:posEnd-1),*) inputindx

            !substring including alpha value for the index.
            posStart=posEnd+1
            posEnd=SCAN(coeffDictString,',')
            !last value will have a } instead of , so grab index and tell loop to finish
            IF (posEnd .eq. 0) THEN
                posEnd=SCAN(coeffDictString,"}")
                continue_flag=.False.
            END IF

            !read that substring
            inputValue=coeffDictString(posStart:posEnd-1)
            READ(inputValue,*) coeffArray(inputIndx)
            !update string to remove this entry
            coeffDictString=coeffDictString(posEnd+1:)
        END DO
    END SUBROUTINE coefficientParser

    SUBROUTINE get_specname(specname_out)
        !Returns:
        ! specname_out - array of species that are in the chemicalabunarray
        !f2py intent(out) specname_out
        CHARACTER(LEN=32), INTENT(OUT) :: specname_out(nspec)
        specname_out(:nspec) = specName
    END SUBROUTINE get_specname

    ! TODO: move this to coolant_module, but coolant_module is not being exposed
    ! to f2py currently. So for now, keep it here.
    !=======================================================================
    !
    !  Wrapper function to get the current coolant restart mode
    !  Accessible from Python via f2py
    !
    !-----------------------------------------------------------------------
    INTEGER FUNCTION get_coolant_restart_mode_wrap()

        IMPLICIT NONE
        !f2py intent(out) get_coolant_restart_mode_wrap
        get_coolant_restart_mode_wrap = GET_COOLANT_RESTART_MODE()
    END FUNCTION get_coolant_restart_mode_wrap


    !=======================================================================
    !
    !  Wrapper subroutine to set the coolant restart mode
    !  Accessible from Python via f2py
    !
    !  mode values:
    !    0 = WARM (default): Initialize to LTE on first call, rescale on density change
    !    1 = FORCE_LTE: Always reset to LTE before SE iteration
    !    2 = FORCE_GROUND: Always reset to ground state before SE iteration
    !
    !-----------------------------------------------------------------------
    SUBROUTINE set_coolant_restart_mode_wrap(mode)
        IMPLICIT NONE
        INTEGER, INTENT(IN) :: mode
        !f2py intent(in) mode
        CALL SET_COOLANT_RESTART_MODE(mode)
    END SUBROUTINE set_coolant_restart_mode_wrap

END MODULE uclchemwrap

