"""Simple script to parse the markdown files created from Tutorial notebooks.

For some reason nbconvert to markdown produces style tags
that cannot be compiled by mdx. So we just remove them.

"""

from pathlib import Path
from sys import argv

if __name__ == "__main__":
    for mdx_file in argv[1:]:
        lines = []
        ignore_lines = False
        with Path(mdx_file).open() as f:
            for line in f.readlines():
                # if a line has style in it, change the flag
                # this way, <style> makes the code start ignoring lines until </style>
                if "style" in line:
                    ignore_lines = not ignore_lines
                    # exception are styles embedded in other tags.
                    # Just keep the flag and don't ignore later lines
                    if "<tr" in line:
                        lines.append("<tr>\n")
                        ignore_lines = False
                # if no style, just add the line
                elif not ignore_lines:
                    lines.append(line)
        with Path(mdx_file).open("w") as f:
            f.writelines(lines)
