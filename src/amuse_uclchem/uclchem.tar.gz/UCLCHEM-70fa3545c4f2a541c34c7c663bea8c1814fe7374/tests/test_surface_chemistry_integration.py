"""Integration test for new surface chemistry features.

Runs a cloud model and verifies the new physics produces different/better results.
"""

import shutil
import tempfile
from pathlib import Path

import pytest

import uclchem


@pytest.fixture
def temp_output_dir():
    """Create temporary directory for test outputs."""
    temp_dir = tempfile.mkdtemp(prefix="uclchem_surface_test_")
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.mark.skip(reason="H2 burial exclusion breaks ML cap")
def test_ice_dependent_desorption_changes_chemistry(temp_output_dir):
    """Test that ice-coverage-dependent desorption actually affects chemistry.

    Verifies:
    - Model runs successfully with new features
    - Ice builds up over time
    - Surface chemistry evolves as ice grows
    - Chemical desorption efficiency varies with coverage

    """
    param_dict = {
        "endAtFinalDensity": False,
        "freefall": False,
        "initialDens": 1.0e4,
        "initialTemp": 10.0,
        "finalTime": 1.0e6,
        "points": 1,  # Explicitly set to 0D mode to avoid state pollution from 1D tests
        "enable_radiative_transfer": False,  # Explicitly disable to avoid state pollution from 1D tests
        "desorb": True,
        "chemdesorb": True,
        "outputFile": str(Path(temp_output_dir) / "surface_test.dat"),
    }

    result = uclchem.model.Cloud(param_dict=param_dict)

    # Basic checks
    assert result is not None, "Model failed to run"
    result.check_error()

    # Get dataframe
    df = result.get_joined_dataframes()
    assert len(df) > 0, "No output produced"

    # Verify ice buildup (SURFACE + BULK = total ice)
    early_ice = df["SURFACE"].iloc[2] + df["BULK"].iloc[2]
    late_ice = df["SURFACE"].iloc[-1] + df["BULK"].iloc[-1]
    assert late_ice > early_ice * 10, (
        f"Ice should build up significantly: {early_ice:.2e} → {late_ice:.2e}"
    )

    # Verify chemistry evolves
    early_co = df["#CO"].iloc[2]
    late_co = df["#CO"].iloc[-1]
    assert late_co != early_co, "Surface CO should evolve"

    # Verify complex molecules form (tests that chemistry is active)
    final_ch4 = df["CH4"].iloc[-1]
    assert final_ch4 > 1e-20, "Complex molecules should form"

    settings = uclchem.advanced.GeneralSettings()
    num_monolayers_is_surface = list(
        settings.search("num_monolayers_is_surface", True, True).values()
    )[0].get()
    gas_dust_density_ratio = list(
        settings.search("gas_dust_density_ratio", True, True).values()
    )[0].get()
    num_sites_per_grain = list(
        settings.search("num_sites_per_grain", True, True).values()
    )[0].get()

    num_monolayers_in_run = (
        df["SURFACE"].max() * gas_dust_density_ratio / num_sites_per_grain
    )

    tol = 5e-2
    assert num_monolayers_in_run <= num_monolayers_is_surface + tol, (
        f"Number of monolayers of surface should be less than {num_monolayers_is_surface}, but was {num_monolayers_in_run:.2f} at most"
    )


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
